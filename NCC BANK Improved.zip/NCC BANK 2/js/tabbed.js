// tabbed item
const btnContainer = document.querySelector(".btn__container");
const btnContainer1 = document.querySelector(".btn__container1");
// const btnContainer2 = document.querySelector(".btn__container2");
const btnP = document.querySelectorAll(".btn__tab");
const btnB = document.querySelectorAll(".btn__tab-business");
const btnR = document.querySelectorAll(".btn__tab-report");
const megaMenuContent = document.querySelectorAll(".mega-menu__content");
const megaMenuContent1 = document.querySelectorAll(".mega-menu__content__1");
const megaMenuContent2 = document.querySelectorAll(".mega-menu__content__2");

btnContainer.addEventListener("mouseover", function (e) {
  e.preventDefault();

  const hovered = e.target.closest(".btn__tab");
  //   const hovered1 = e.target.closest(".btn__tab-business");
  //   console.log(hovered, hovered1);

  if (!hovered) return;

  // console.log("Am in personal");
  btnP.forEach((btn) => btn.classList.remove("btn__tab-active"));
  hovered.classList.add("btn__tab-active");
  megaMenuContent.forEach((content) =>
    content.classList.remove("mega-menu__content-active")
  );

  document
    .querySelector(`.mega-menu__content-${hovered.dataset.tab}`)
    .classList.add("mega-menu__content-active");
});

btnContainer1.addEventListener("mouseover", function (e) {
  e.preventDefault();
  const hovered1 = e.target.closest(".btn__tab-business");
  //   console.log(hovered, hovered1);

  if (!hovered1) return;

  btnB.forEach((btn) => btn.classList.remove("btn__tab-active"));
  hovered1.classList.add("btn__tab-active");
  megaMenuContent1.forEach((content) => {
    content.classList.remove("mega-menu__content-active-1");
  });

  console.log(
    document.querySelector(`.mega-menu__content${hovered1.dataset.tab}`)
  );
  document
    .querySelector(`.mega-menu__content${hovered1.dataset.tab}`)
    .classList.add("mega-menu__content-active-1");
});

const hamburger = document.querySelector(".hamburger");
hamburger.addEventListener("click", function () {
  this.classList.toggle("close");
});

// calculator section
// tabbed component

const tabsContainer = document.querySelector(".tab__container");
const tabs = document.querySelectorAll(".operations__tab");
const tabsContent = document.querySelectorAll(".operations__content");

tabsContainer.addEventListener("click", function (e) {
  const clicked = e.target.closest(".operations__tab");

  if (!clicked) return;

  tabs.forEach((tab) => tab.classList.remove("operations__tab--active"));
  clicked.classList.add("operations__tab--active");
  // console.log();
  tabsContent.forEach((tc) =>
    tc.classList.remove("operations__content--active")
  );

  document
    .querySelector(`.operations__content--${clicked.dataset.tab}`)
    .classList.add("operations__content--active");
});

// scroll
