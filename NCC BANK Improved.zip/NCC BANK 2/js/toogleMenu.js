const menu = document.querySelector(".hamburger");
const mobileMenu = document.querySelector(".menu");
const overlay = document.querySelector(".overlay");
const img = document.querySelectorAll(".logo a img");

menu.addEventListener("click", function () {
  overlay.classList.toggle("active");
  mobileMenu.style.right = "-3.5rem";
  img.forEach((i) => i.classList.toggle("blur"));
});

overlay.addEventListener("click", function () {
  document.getElementById("input-hamburger").checked = false;
  overlay.classList.toggle("active");
  menu.classList.remove("close");
});
