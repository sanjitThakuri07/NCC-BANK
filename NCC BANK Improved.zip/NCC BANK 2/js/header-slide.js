const slider = document.querySelector(".header__slider");

const slides = document.querySelectorAll(".header__slider-slide");

const dotContainer = document.querySelector(".dots");
let currentSlide = 0;

// slide animation
const slideAnimation = function slideAnimation(
  container,
  slideNumber,
  translate
) {
  container.forEach((el, i) => {
    // console.log("hey");
    // el.style.backgroundColor = "red";
    // console.log(trnaslate);
    el.style.transform = `${translate}(${(i - slideNumber) * 100}%)`;
  });
};

slideAnimation(slides, 0, "translateX");

// create dots
const createDots = function () {
  slides.forEach((_, i) => {
    dotContainer.insertAdjacentHTML(
      "beforeend",
      `<button class="dots__dot" data-slide="${i}">`
    );
  });
};

createDots();

// active dots
const activeDots = function (slideNumber) {
  document
    .querySelectorAll(".dots__dot")
    .forEach((el) => el.classList.remove("dots__dot--active"));
  document
    .querySelector(`.dots__dot[data-slide= "${slideNumber}"]`)
    .classList.add("dots__dot--active");
};

//slide from dot
dotContainer.addEventListener("click", function (e) {
  const slideNumber = e.target.dataset.slide;
  console.log(slideNumber);
  slideAnimation(slides, slideNumber, "translateX");
  activeDots(slideNumber);
});

activeDots(0);

// // vertical slide
// let currentSlide1 = 0;

// const newsContent = document.querySelectorAll(".news__list-slider");
// const topArrowBtn = document.querySelector(".top-btn");
// const bottomArrowBtn = document.querySelector(".down-btn");

// topArrowBtn.addEventListener("click", function () {
//   if (currentSlide1 === newsContent.length - 1) {
//     return;
//   } else {
//     currentSlide1++;
//     slideAnimation(newsContent, currentSlide1, "translateY");
//     console.log(currentSlide1);
//   }
// });

// bottomArrowBtn.addEventListener("click", function () {
//   if (currentSlide1 === 0) {
//     return;
//   } else {
//     currentSlide1--;
//     slideAnimation(newsContent, currentSlide1, "translateY");
//     console.log(currentSlide1);
//   }
// });

// slideAnimation(newsContent, 0, "translateY");
