const labelPrinciple = document.querySelector(".principle");

const labelRate = document.querySelector(".rate");

const labelMonth = document.querySelector(".month");

const calculateBtn = document.querySelector(".submit__button");

const displayOutput = document.querySelector(".display__output");

// avoid negative input

// Listen for input event on numInput.

// avoid symbols and negative signs
function checkSymbol(e) {
  if (e.keyCode == 110) {
    return true;
  }
  if (
    !(
      (e.keyCode > 95 && e.keyCode < 106) ||
      (e.keyCode > 47 && e.keyCode < 58) ||
      e.keyCode == 8
    )
  ) {
    console.log(e.which);
    return false;
  }
}

labelPrinciple.onkeydown = checkSymbol;
labelMonth.onkeydown = checkSymbol;
labelRate.onkeydown = checkSymbol;

// calculation

function calculate(principle, rate, month) {
  let r = rate / 12 / 100; //convert rate into monthly
  let re = (1 + r) ** month; // power
  //   console.log(r);
  return (principle * r * re) / (re - 1);
}

// P × r × (1 + r)n/((1 + r)n - 1)

// event
calculateBtn.addEventListener("click", function (e) {
  e.preventDefault();

  const principle = +labelPrinciple.value;

  const interestRate = +labelRate.value;

  const month = +labelMonth.value;

  if (!principle || !interestRate || !month) {
    return alert("Please Fill Out All The Details");
  }
  const emi = calculate(principle, interestRate, month).toFixed(2);

  displayOutput.value = `Rs.${emi}`;
});
